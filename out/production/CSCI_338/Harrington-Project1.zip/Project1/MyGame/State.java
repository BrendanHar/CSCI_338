package Project1.MyGame;

public interface State {

    public void dodge();
    public void run();
    public void crouch();
    public void die();
    public void stop();
    public void heal();
    public void slash();
    public void fireball();
//    public void restart();


}
