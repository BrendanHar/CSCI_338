package Project1.Proj1_code_assigned;

/**
 *
 * @author yaw
 */
public interface State {
    public void insertQuarter();
    public void removeQuarter();
    public void turnCrank();
    public void refillGumballMachine(int num);

}
